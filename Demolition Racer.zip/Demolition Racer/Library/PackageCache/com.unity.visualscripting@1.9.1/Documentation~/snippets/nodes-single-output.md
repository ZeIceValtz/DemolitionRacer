---
title: nodes-single-output
---

node has one output port: