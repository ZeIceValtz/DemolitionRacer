---
title: nodes-note-package
---

is an [Input System package](https://docs.unity3d.com/Packages/com.unity.inputsystem@latest) node. For more information about how to use the Input System package in Visual Scripting, see [Capture user input in an application](../../vs-capture-player-input.md).