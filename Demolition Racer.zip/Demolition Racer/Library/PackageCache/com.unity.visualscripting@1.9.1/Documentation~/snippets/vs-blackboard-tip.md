---
title: blackboard-tip
---

> [!TIP]
> If the Blackboard isn't visible in the Graph window, select **Blackboard** (![The Blackboard icon](../images/vs-blackboard-icon.png)) from the toolbar.
