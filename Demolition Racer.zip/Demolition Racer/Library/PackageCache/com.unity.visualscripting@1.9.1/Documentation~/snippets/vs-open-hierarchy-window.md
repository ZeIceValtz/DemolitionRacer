---
title: open-hierarchy-window
---

Go to **Window** &gt; **General** &gt; **Hierarchy**, or press Ctrl+4 (macOS: Cmd+4) to open the [Hierarchy window](https://docs.unity3d.com/Manual/Hierarchy.html).
