namespace Unity.VisualScripting
{
    public sealed class UnitAnalysis : GraphElementAnalysis
    {
        public bool isEntered { get; set; }
    }
}
