namespace Unity.VisualScripting
{
    public enum NodeColor
    {
        Gray = 0,
        Blue = 1,
        Teal = 2,
        Green = 3,
        Yellow = 4,
        Orange = 5,
        Red = 6
    }
}
