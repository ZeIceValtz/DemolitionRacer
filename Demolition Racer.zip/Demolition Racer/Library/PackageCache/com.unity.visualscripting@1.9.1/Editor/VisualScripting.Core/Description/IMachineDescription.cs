namespace Unity.VisualScripting
{
    public interface IMachineDescription : IDescription { }
}
