namespace Unity.VisualScripting
{
    public class MachineDescription : Description, IMachineDescription { }
}
